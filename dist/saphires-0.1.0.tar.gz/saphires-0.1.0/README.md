# SAPHIRES
SAPHIRES - Stellar Analysis in Python for HIgh REsolution Spectroscopy

This python package includes some common tools for the ananlysis of high resolution spectroscopy 
that don't typically have esaily accessible python versions.

It currently includes nothing, but will soon include the following tools:

- Fourier Cross Correlation

- TODCOR (Two-Dimensional Cross Correlation)

- Spectral Line Broadening Functions
