from distutils.core import setup

setup(name='saphires',
      version='0.1.3',
      description='Stellar Analysis in Python for HIgh-REsolution Spectroscopy',
      author='Ben Tofflemire',
      author_email='tofflemire@utexas.edu',
      url='https://github.com/tofflemire/saphires',
      license='BSD/MIT',
      classifiers=[
          'Development Status :: 3 - Alpha',
          'Intended Audience :: Science/Research',
          'License :: OSI Approved :: BSD License',
          'Programming Language :: Python',
          'Topic :: Scientific/Engineering :: Astronomy',
          ],
      packages=['saphires','saphires.extras'],
      requires=['numpy',
                'astropy',
                'scipy',
                'matplotlib',
                'pickle',
                'PyQt5',
                'pdyl'])
